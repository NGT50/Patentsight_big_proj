// src/pages/DocumentEditor.jsx

import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import {
  getLatestDocument,
  updateDocumentContent,
  createNewVersion,
  generateClaimDraft,
  generateRejectionDraft,
  validatePatentDocument,
  startChatSession,
} from '../api/patents';
import AiDraftPanel from '../components/AiDraftPanel';
import AiCheckPanel from '../components/AiCheckPanel';

const DocumentEditor = () => {
  const { patentId } = useParams();
  const [document, setDocument] = useState(null);
  const [editableContent, setEditableContent] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchLatestDoc = async () => {
      try {
        const res = await getLatestDocument(patentId);
        setDocument(res.document);
        setEditableContent(res.document);
      } catch (err) {
        console.error(err);
        alert('문서 정보를 불러오는 데 실패했습니다.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchLatestDoc();
  }, [patentId]);

  const handleChange = (field, value) => {
    setEditableContent((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleInventionDetailsChange = (field, value) => {
    setEditableContent((prev) => ({
      ...prev,
      inventionDetails: {
        ...prev.inventionDetails,
        [field]: value,
      },
    }));
  };

  const handleSave = async () => {
    try {
      await updateDocumentContent(patentId, editableContent);
      alert('문서가 저장되었습니다.');
    } catch (err) {
      console.error(err);
      alert('저장 실패');
    }
  };

  const handleSaveNewVersion = async () => {
    try {
      const payload = {
        newDocument: editableContent,
        authorId: 1, // TODO: 현재 로그인된 사용자 ID로 교체
        changeSummary: '신규 버전 저장',
      };
      await createNewVersion(patentId, payload);
      alert('새 문서 버전이 저장되었습니다.');
    } catch (err) {
      console.error(err);
      alert('버전 저장 실패');
    }
  };

  const handleGenerateClaim = async () => {
    try {
      const res = await generateClaimDraft(patentId);
      alert('청구항 초안 생성 완료');
      console.log(res);
    } catch (err) {
      console.error(err);
      alert('청구항 초안 생성 실패');
    }
  };

  const handleGenerateRejection = async () => {
    try {
      const res = await generateRejectionDraft(patentId);
      alert('거절 사유 초안 생성 완료');
      console.log(res);
    } catch (err) {
      console.error(err);
      alert('거절 사유 초안 생성 실패');
    }
  };

  const handleValidateDocument = async () => {
    try {
      const res = await validatePatentDocument(patentId);
      alert('문서 점검 완료');
      console.log(res);
    } catch (err) {
      console.error(err);
      alert('문서 점검 실패');
    }
  };

  const handleStartChat = async () => {
    try {
      const res = await startChatSession(patentId);
      alert(`GPT 세션 시작됨 (ID: ${res.session_id})`);
      console.log(res);
    } catch (err) {
      console.error(err);
      alert('GPT 세션 생성 실패');
    }
  };

  if (isLoading) return <div>로딩 중...</div>;
  if (!editableContent) return <div>문서를 찾을 수 없습니다.</div>;

  return (
    <div style={{ padding: '24px' }}>
      <h1>📄 출원 문서 편집기</h1>

      {/* 🔹 AI 기능 버튼 */}
      <div style={{ display: 'flex', gap: '12px', marginBottom: '24px' }}>
        <button onClick={handleGenerateClaim}>청구항 초안 생성</button>
        <button onClick={handleGenerateRejection}>거절 사유 초안 생성</button>
        <button onClick={handleValidateDocument}>문서 오류 점검</button>
        <button onClick={handleStartChat}>GPT 대화 시작</button>
      </div>

      {/* 🔹 필드 입력 */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        <input
          value={editableContent.title}
          onChange={(e) => handleChange('title', e.target.value)}
          placeholder="발명의 명칭"
        />

        <input
          value={editableContent.inventor}
          onChange={(e) => handleChange('inventor', e.target.value)}
          placeholder="출원인"
        />

        <input
          value={editableContent.cpc}
          onChange={(e) => handleChange('cpc', e.target.value)}
          placeholder="CPC 분류"
        />

        <textarea
          value={editableContent.technicalField}
          onChange={(e) => handleChange('technicalField', e.target.value)}
          placeholder="기술 분야"
        />

        <textarea
          value={editableContent.backgroundTechnology}
          onChange={(e) => handleChange('backgroundTechnology', e.target.value)}
          placeholder="배경 기술"
        />

        <textarea
          value={editableContent.inventionDetails.problemToSolve}
          onChange={(e) => handleInventionDetailsChange('problemToSolve', e.target.value)}
          placeholder="해결 과제"
        />

        <textarea
          value={editableContent.inventionDetails.solution}
          onChange={(e) => handleInventionDetailsChange('solution', e.target.value)}
          placeholder="기술 수단"
        />

        <textarea
          value={editableContent.inventionDetails.effect}
          onChange={(e) => handleInventionDetailsChange('effect', e.target.value)}
          placeholder="기대 효과"
        />

        <textarea
          value={editableContent.summary}
          onChange={(e) => handleChange('summary', e.target.value)}
          placeholder="요약 설명"
        />

        <textarea
          value={editableContent.drawingDescription}
          onChange={(e) => handleChange('drawingDescription', e.target.value)}
          placeholder="도면 설명"
        />

        <textarea
          value={editableContent.claims?.join('\n')}
          onChange={(e) =>
            handleChange('claims', e.target.value.split('\n').filter((line) => line.trim() !== ''))
          }
          placeholder="청구항 목록 (줄바꿈으로 구분)"
        />
      </div>

      {/* 🔹 저장 버튼 */}
      <div style={{ marginTop: '24px' }}>
        <button onClick={handleSave}>💾 저장</button>
        <button onClick={handleSaveNewVersion} style={{ marginLeft: '8px' }}>
          📌 새 버전으로 저장
        </button>
        {patentId && <AiDraftPanel patentId={patentId} />}
        {patentId && <AiCheckPanel patentId={patentId} />}
        {patentId && <VersionHistory patentId={patentId} />}
        {sessionId && <ChatBotBox sessionId={sessionId} />}
      </div>
    </div>
  );
};

export default DocumentEditor;
