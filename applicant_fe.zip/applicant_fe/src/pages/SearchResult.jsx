import React, { useState } from 'react';
import PatentCard from '../components/PatentCard';
import PatentDetailModal from '../components/PatentDetailModal';

const SearchResult = () => {
  const [selectedPatent, setSelectedPatent] = useState(null);

  // 필터링 상태값
  const [scope, setScope] = useState('국내'); // '국내' or '해외'
  const [statusFilter, setStatusFilter] = useState({ 전체: true, 등록: false, 거절: false });
  const [sortBy, setSortBy] = useState('기본정렬');

  const dummyPatents = [
    {
      id: 1,
      title: '회전 나사 고정 장치',
      applicant: '홍길동',
      status: '등록',
      isOverseas: false,
      date: '2021-08-10',
      applicationNumber: 'KR20210001',
    },
    {
      id: 2,
      title: '자동 토크 조절 장치',
      applicant: '김지민',
      status: '거절',
      isOverseas: false,
      date: '2020-12-02',
      applicationNumber: 'KR20200077',
    },
    {
      id: 3,
      title: '나사 제어 구조',
      applicant: 'John Smith',
      status: '등록',
      isOverseas: true,
      date: '2022-02-15',
      applicationNumber: 'US20220011',
    },
  ];

  // ✅ 필터링된 특허 목록 생성
  const filteredPatents = dummyPatents.filter((patent) => {
    const isMatchingScope = scope === '국내' ? !patent.isOverseas : patent.isOverseas;

    const isMatchingStatus =
      statusFilter['전체'] ||
      (statusFilter['등록'] && patent.status === '등록') ||
      (statusFilter['거절'] && patent.status === '거절');
    
    return isMatchingScope && isMatchingStatus;
  });

  // ✅ 정렬 적용
  const sortedPatents = [...filteredPatents];
  if (sortBy === '출원일자') {
    sortedPatents.sort((a, b) => new Date(b.date) - new Date(a.date));
  } else if (sortBy === '출원번호') {
    sortedPatents.sort((a, b) => (a.applicationNumber || '').localeCompare(b.applicationNumber || ''));
  } else if (sortBy === '행정상태') {
    sortedPatents.sort((a, b) => a.status.localeCompare(b.status));
  } else if (sortBy === '발명의 명칭') {
    sortedPatents.sort((a, b) => a.title.localeCompare(b.title));
  }

  // 🔧 필터 UI
  const renderFilterBar = () => (
    <div style={{ marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '16px' }}>
      {/* 1-2 국내/해외 버튼 */}
      <div>
        <button onClick={() => setScope('국내')} style={{ backgroundColor: scope === '국내' ? '#ccc' : '#eee' }}>
          국내
        </button>
        <button onClick={() => setScope('해외')} style={{ backgroundColor: scope === '해외' ? '#ccc' : '#eee', marginLeft: '4px' }}>
          해외
        </button>
      </div>

      {/* 1-3 상태 체크박스 */}
      <div>
        {['전체', '등록', '거절'].map((label) => (
          <label key={label} style={{ marginRight: '8px' }}>
            <input
              type="checkbox"
              checked={statusFilter[label]}
              onChange={() =>
                setStatusFilter((prev) => {
                  if (label === '전체') {
                    return { 전체: !prev.전체, 등록: false, 거절: false };
                  } else {
                    return { ...prev, [label]: !prev[label], 전체: false };
                  }
                })
              }
            />
            {label}
          </label>
        ))}
      </div>

      {/* 1-4 정렬 기준 */}
      <div>
        <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
          <option>기본정렬</option>
          <option>출원일자</option>
          <option>출원번호</option>
          <option>행정상태</option>
          <option>발명의 명칭</option>
        </select>
      </div>
    </div>
  );

  return (
    <div style={{ padding: '24px' }}>
      <h1>🔍 검색 결과</h1>
      {renderFilterBar()}

      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', marginTop: '24px' }}>
        {sortedPatents.map((patent) => (
          <PatentCard key={patent.id} data={patent} onClick={() => setSelectedPatent(patent)} />
        ))}
      </div>

      {selectedPatent && (
        <PatentDetailModal patent={selectedPatent} onClose={() => setSelectedPatent(null)} />
      )}
    </div>
  );
};

export default SearchResult;
